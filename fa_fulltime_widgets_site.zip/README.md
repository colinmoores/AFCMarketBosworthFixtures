# FA Full-Time Widgets Website

This website embeds three FA Full-Time widgets using the provided HTML and JavaScript code.

## 🚀 How to Publish on GitHub Pages

1. Go to https://github.com and create a new repository (e.g., `fa-fulltime-widgets`).
2. Upload the contents of this zip file (`index.html` and `README.md`) to the repository.
3. Navigate to **Settings** → **Pages**.
4. Under **Source**, select your branch (e.g., `main`) and root folder (`/`).
5. Click **Save**.
6. Your site will be live at:  
   `https://<your-username>.github.io/fa-fulltime-widgets/`
